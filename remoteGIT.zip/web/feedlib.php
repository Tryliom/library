<?php

echo file_get_contents('http://localhost:6080/library/feed/5');






?>


/type/author	/authors/OL100995A	1	2008-04-01T03:28:50.625462	
{
	"name": "Prama\u0304n \u02bbAdire\u0304ksa\u0304n", 
	"personal_name": "Prama\u0304n \u02bbAdire\u0304ksa\u0304n", 
	"last_modified": 
	{
		"type": "/type/datetime", 
		"value": "2008-04-01T03:28:50.625462"
	}, 
	"key": "/authors/OL100995A", 
	"birth_date": "1913", 
	"type": {
		"key": "/type/author"
	}, 
	"revision": 1
}
