package me.alexishaldy.enumerator;

/**
 * List: Number, title, author, year, title_author, title_author_numedition, desc
 * @author haldy
 *
 */
public enum SortType {
	Number, title, author, year, title_author, title_author_numedition, desc;
}
