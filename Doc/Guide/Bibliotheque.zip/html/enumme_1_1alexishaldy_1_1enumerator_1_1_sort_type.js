var enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type =
[
    [ "author", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html#a74d9d43c684b95097d4eb91cfae10f1b", null ],
    [ "Number", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html#a027d151f559ef89662a19b12022bdedd", null ],
    [ "title", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html#a3ad3c85ce439b88f5b15a29721164e53", null ],
    [ "title_author", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html#a6dc0b81debf40415a764867eb79b2ec1", null ],
    [ "title_author_numedition", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html#a5a635c1ece01a5c8e570112cdd77068e", null ],
    [ "year", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html#a21a1e644f5f040fee7baee0cb3902bd6", null ]
];