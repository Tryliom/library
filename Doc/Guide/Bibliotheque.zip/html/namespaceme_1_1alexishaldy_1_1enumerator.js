var namespaceme_1_1alexishaldy_1_1enumerator =
[
    [ "HttpResponseCode", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code" ],
    [ "SortType", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type" ]
];