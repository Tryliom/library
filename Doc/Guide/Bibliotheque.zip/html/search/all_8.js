var searchData=
[
  ['listauthors',['listAuthors',['../classme_1_1alexishaldy_1_1util_1_1_utils.html#a8017ef1afa0b2436bedf1c6e8376e451',1,'me::alexishaldy::util::Utils']]],
  ['listbook',['listBook',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#a2db2068e400800b7e9614fc7f6bec3d0',1,'me::alexishaldy::rest::RestHandler']]]
];
