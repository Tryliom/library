var searchData=
[
  ['rest_5fconf',['REST_CONF',['../classme_1_1alexishaldy_1_1util_1_1_utils.html#a0505989ba974772f7d2ab665ea799fb0',1,'me::alexishaldy::util::Utils']]],
  ['resthandler',['RestHandler',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html',1,'me::alexishaldy::rest']]],
  ['resthandler_2ejava',['RestHandler.java',['../_rest_handler_8java.html',1,'']]],
  ['returnbook',['returnBook',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#a54409a8c2152996d1c5cce29d42f46ed',1,'me::alexishaldy::rest::RestHandler']]]
];
