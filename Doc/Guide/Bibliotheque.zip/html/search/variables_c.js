var searchData=
[
  ['user',['user',['../classme_1_1alexishaldy_1_1db_1_1connection_1_1_d_b_connection.html#ad9e675111515cb576b5a047e53c7fd84',1,'me::alexishaldy::db::connection::DBConnection']]]
];
