var searchData=
[
  ['dbconnection',['DBConnection',['../classme_1_1alexishaldy_1_1db_1_1connection_1_1_d_b_connection.html#a248608834aea5e237913ee3a92faddba',1,'me::alexishaldy::db::connection::DBConnection']]],
  ['dbconnectionadapter',['DBConnectionAdapter',['../classme_1_1alexishaldy_1_1db_1_1connection_1_1_d_b_connection_adapter.html#a0c92f3e6e9dc7ca55be2b8c3002411f5',1,'me::alexishaldy::db::connection::DBConnectionAdapter']]],
  ['dbexception',['DBException',['../classme_1_1alexishaldy_1_1exception_1_1_d_b_exception.html#afa80c6bcf40f53931dc8b6e7f45fbfc3',1,'me.alexishaldy.exception.DBException.DBException(final String message)'],['../classme_1_1alexishaldy_1_1exception_1_1_d_b_exception.html#a09c65622ab90e17f116174ff751b4309',1,'me.alexishaldy.exception.DBException.DBException(final String message, final int errorCode)']]],
  ['deletebook',['deleteBook',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#a0ff9141c937dacae5e08886300696b33',1,'me::alexishaldy::rest::RestHandler']]],
  ['deletelib',['deleteLib',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#ae7795b1b3916f14c3648f5afe210545a',1,'me::alexishaldy::rest::RestHandler']]],
  ['deleteuser',['deleteUser',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#a952c6138683ba35e2fc8118b8ca7c01a',1,'me::alexishaldy::rest::RestHandler']]]
];
