var namespaceme_1_1alexishaldy_1_1classes =
[
    [ "Book", "classme_1_1alexishaldy_1_1classes_1_1_book.html", "classme_1_1alexishaldy_1_1classes_1_1_book" ]
];