var hierarchy =
[
    [ "me.alexishaldy.classes.Book", "classme_1_1alexishaldy_1_1classes_1_1_book.html", null ],
    [ "me.alexishaldy.db.table.Column", "classme_1_1alexishaldy_1_1db_1_1table_1_1_column.html", null ],
    [ "me.alexishaldy.db.connection.DBConnection", "classme_1_1alexishaldy_1_1db_1_1connection_1_1_d_b_connection.html", [
      [ "me.alexishaldy.db.connection.DBConnectionAdapter", "classme_1_1alexishaldy_1_1db_1_1connection_1_1_d_b_connection_adapter.html", null ]
    ] ],
    [ "me.alexishaldy.db.pool.DBConnectionPool", "classme_1_1alexishaldy_1_1db_1_1pool_1_1_d_b_connection_pool.html", null ],
    [ "me.alexishaldy.db.connection.DBExecutor", "classme_1_1alexishaldy_1_1db_1_1connection_1_1_d_b_executor.html", null ],
    [ "Exception", null, [
      [ "me.alexishaldy.exception.DBException", "classme_1_1alexishaldy_1_1exception_1_1_d_b_exception.html", null ]
    ] ],
    [ "me.alexishaldy.enumerator.HttpResponseCode", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html", null ],
    [ "me.alexishaldy.rest.JSONGenerator", "classme_1_1alexishaldy_1_1rest_1_1_j_s_o_n_generator.html", null ],
    [ "me.alexishaldy.rest.RestHandler", "classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html", null ],
    [ "me.alexishaldy.rest.Server", "classme_1_1alexishaldy_1_1rest_1_1_server.html", null ],
    [ "me.alexishaldy.enumerator.SortType", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html", null ],
    [ "me.alexishaldy.util.Utils", "classme_1_1alexishaldy_1_1util_1_1_utils.html", null ]
];