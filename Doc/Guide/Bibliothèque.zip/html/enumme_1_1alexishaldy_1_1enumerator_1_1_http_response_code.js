var enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code =
[
    [ "HttpResponseCode", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html#a371ed7a4a7af920481ab1790c8750465", null ],
    [ "getValue", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html#a1ec3c557c70f1cfbbc47acf26610289f", null ],
    [ "NOK", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html#a7ff4e1c5af27e2f139bd98c35c068d21", null ],
    [ "OK", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html#ad80700b67efccb1fcce70e2fad61e02f", null ]
];