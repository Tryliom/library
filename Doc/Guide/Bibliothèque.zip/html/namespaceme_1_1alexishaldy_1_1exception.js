var namespaceme_1_1alexishaldy_1_1exception =
[
    [ "DBException", "classme_1_1alexishaldy_1_1exception_1_1_d_b_exception.html", "classme_1_1alexishaldy_1_1exception_1_1_d_b_exception" ]
];