var dir_32080750ec8e505cb6fd7f9419bb83ef =
[
    [ "HttpResponseCode.java", "_http_response_code_8java.html", [
      [ "HttpResponseCode", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code.html", "enumme_1_1alexishaldy_1_1enumerator_1_1_http_response_code" ]
    ] ],
    [ "SortType.java", "_sort_type_8java.html", [
      [ "SortType", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type.html", "enumme_1_1alexishaldy_1_1enumerator_1_1_sort_type" ]
    ] ]
];