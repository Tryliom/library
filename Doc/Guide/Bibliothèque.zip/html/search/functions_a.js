var searchData=
[
  ['returnbook',['returnBook',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#a54409a8c2152996d1c5cce29d42f46ed',1,'me::alexishaldy::rest::RestHandler']]]
];
