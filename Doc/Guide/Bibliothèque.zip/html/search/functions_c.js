var searchData=
[
  ['takebook',['takeBook',['../classme_1_1alexishaldy_1_1rest_1_1_rest_handler.html#aebbc131bbb11e313c6b7ab2a3e504057',1,'me::alexishaldy::rest::RestHandler']]]
];
