var classme_1_1alexishaldy_1_1classes_1_1_book =
[
    [ "Book", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a0f48e2b441eeb5600fa0cd43600bfee5", null ],
    [ "getAuthor", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a292ca422c9a1258cd5ce7ab9af36785c", null ],
    [ "getDate", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a880b6bdc690685ee44a983ac9863a21e", null ],
    [ "getDesc", "classme_1_1alexishaldy_1_1classes_1_1_book.html#aa99ccce53e8adf7aa9ef56903d467d1c", null ],
    [ "getEditeur", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a21f50887c441d88c9c213adb7b380b9c", null ],
    [ "getEdition", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a792860ad3bf07af0cbeced165768556a", null ],
    [ "getTitle", "classme_1_1alexishaldy_1_1classes_1_1_book.html#abf540611de9dfc7dccf07ed473932312", null ],
    [ "setAuthor", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a2da54a80d00350441b88534f09926882", null ],
    [ "setDate", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a45e1d36001b9e56576b3b8957eb8fc1c", null ],
    [ "setDesc", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a8d38bb3c996fb7a721912f5fae44a03f", null ],
    [ "setEditeur", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a7a19eafbc5474a5d57d45f27b1d3e908", null ],
    [ "setEdition", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a6ca39f4e84a752e21e0168b95575c12b", null ],
    [ "setTitle", "classme_1_1alexishaldy_1_1classes_1_1_book.html#a2bd4487f2a181a3aae933d8745cd436b", null ]
];